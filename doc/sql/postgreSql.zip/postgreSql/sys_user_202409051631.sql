INSERT INTO public.sys_user (id,user_name,nick_name,"password",phone_number,remark,disabled,created_by,created_time) VALUES
	 (1,'admin','Admin','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','18470778273','系统管理员',0,'script','2024-08-02 11:24:59.965177'),
	 (0,'user01','demo','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','123333','演示',0,'admin','2024-08-02 16:30:09.834383'),
	 (577721277424005,'demo','demo1','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','123333','演示用户',0,'admin','2024-08-09 21:33:55.766823');
