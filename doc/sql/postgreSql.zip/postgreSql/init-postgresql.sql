-- public.job_info definition

-- Drop table

-- DROP TABLE public.job_info;

CREATE TABLE public.job_info (
	id int8 NOT NULL,
	job_name varchar(100) NOT NULL,
	category varchar(100) NOT NULL,
	assembly_name varchar(255) NOT NULL,
	type_name varchar(255) NOT NULL,
	job_key varchar(100) NOT NULL,
	job_group varchar(100) NOT NULL,
	cron_expression varchar(20) NOT NULL,
	misfire_policy int4 NOT NULL,
	concurrent bool NOT NULL,
	status int4 NOT NULL,
	seconds int4 NOT NULL,
	repeat int4 NOT NULL,
	CONSTRAINT job_info_pkey PRIMARY KEY (id)
);


-- public.job_log definition

-- Drop table

-- DROP TABLE public.job_log;

CREATE TABLE public.job_log (
	id int8 NOT NULL,
	job_name varchar(100) NOT NULL,
	category varchar(100) NOT NULL,
	type_name varchar(255) NOT NULL,
	job_message text NOT NULL,
	exception_info text NOT NULL,
	status bool NOT NULL,
	start_time timestamp NOT NULL,
	stop_time timestamp NOT NULL,
	CONSTRAINT job_log_pkey PRIMARY KEY (id)
);


-- public.sys_log definition

-- Drop table

-- DROP TABLE public.sys_log;

CREATE TABLE public.sys_log (
	id int8 NOT NULL,
	operation varchar(255) NOT NULL,
	request_param text NOT NULL,
	response_param text NOT NULL,
	operator_name varchar(255) NOT NULL,
	operate_time timestamp NOT NULL,
	execute_time int8 NOT NULL,
	execute_status bool NOT NULL,
	reason text NOT NULL,
	"path" varchar(255) NOT NULL,
	CONSTRAINT sys_log_pk PRIMARY KEY (id)
);


-- public.sys_menu definition

-- Drop table

-- DROP TABLE public.sys_menu;

CREATE TABLE public.sys_menu (
	id int8 NOT NULL,
	parent_id int8 NOT NULL,
	title varchar(255) NOT NULL,
	"type" int4 NOT NULL,
	icon varchar(255) NOT NULL,
	route varchar(255) NOT NULL,
	keep_alive varchar(255) NOT NULL,
	"key" varchar(255) NOT NULL,
	"path" varchar(255) NOT NULL,
	pem varchar(255) NOT NULL,
	"enable" int4 NOT NULL,
	"show" int4 NOT NULL,
	target int4 NOT NULL,
	query varchar(255) NOT NULL,
	"order" int4 NOT NULL,
	created_time timestamp NOT NULL,
	CONSTRAINT sys_menu_pkey PRIMARY KEY (id)
);


-- public.sys_role definition

-- Drop table

-- DROP TABLE public.sys_role;

CREATE TABLE public.sys_role (
	id int8 NOT NULL,
	role_name varchar(255) NOT NULL,
	role_key varchar(255) NOT NULL,
	disabled int4 NOT NULL,
	created_by varchar(255) NOT NULL,
	created_time timestamp NOT NULL,
	remark varchar(255) NOT NULL,
	CONSTRAINT sys_role_pkey PRIMARY KEY (id)
);


-- public.sys_role_and_menu definition

-- Drop table

-- DROP TABLE public.sys_role_and_menu;

CREATE TABLE public.sys_role_and_menu (
	menu_id int8 NOT NULL,
	role_id int8 NOT NULL
);


-- public.sys_user definition

-- Drop table

-- DROP TABLE public.sys_user;

CREATE TABLE public.sys_user (
	id int8 NOT NULL,
	user_name varchar(255) NOT NULL,
	nick_name varchar(255) NOT NULL,
	"password" varchar(255) NOT NULL,
	phone_number varchar(255) NOT NULL,
	remark varchar(255) NOT NULL,
	disabled int4 NOT NULL,
	created_by varchar(255) NOT NULL,
	created_time timestamp NOT NULL,
	CONSTRAINT sys_user_pkey PRIMARY KEY (id)
);


-- public.sys_user_and_role definition

-- Drop table

-- DROP TABLE public.sys_user_and_role;

CREATE TABLE public.sys_user_and_role (
	user_id int8 NOT NULL,
	role_id int8 NOT NULL
);