INSERT INTO public.sys_role (id,role_name,role_key,disabled,created_by,created_time,remark) VALUES
	 (575100325687685,'superAdmin','superAdmin',0,'admin','2024-08-02 11:49:14.969656','超级管理员'),
	 (575166027358597,'user','user',0,'admin','2024-08-02 16:16:35.41789','普通用户'),
	 (577720630903173,'demo','demo',0,'admin','2024-08-09 21:31:17.924026','演示角色');
