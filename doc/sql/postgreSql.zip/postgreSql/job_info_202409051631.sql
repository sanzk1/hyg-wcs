INSERT INTO public.job_info (id,job_name,category,assembly_name,type_name,job_key,job_group,cron_expression,misfire_policy,concurrent,status,seconds,repeat) VALUES
	 (586216676422021,'测试计划1','系统','quartzModeule','quartzModeule.Job.TestJob','jobKey1','jobGroup1','0/5 * * * * ?',2,false,0,0,-1);
